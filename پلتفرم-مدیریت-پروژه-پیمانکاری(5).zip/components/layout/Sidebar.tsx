import React from 'react';
import { HomeIcon, FolderIcon, ChartBarIcon, CogIcon } from '../icons/Icons';

const Sidebar: React.FC = () => {
  const navItems = [
    { icon: <HomeIcon />, name: 'داشبورد' },
    { icon: <FolderIcon />, name: 'پروژه‌ها' },
    { icon: <ChartBarIcon />, name: 'گزارشات' },
    { icon: <CogIcon />, name: 'تنظیمات' },
  ];

  return (
    <aside className="w-20 md:w-64 bg-[var(--color-surface)] p-2 md:p-4 flex flex-col items-center md:items-start border-l border-[var(--color-border)]">
      <div className="w-full text-center md:text-right mb-10">
        <h1 className="text-xl font-bold text-[var(--color-accent)] hidden md:block">Gemini App</h1>
        <h1 className="text-xl font-bold text-[var(--color-accent)] md:hidden">GA</h1>
      </div>
      <nav className="flex flex-col space-y-2 w-full">
        {navItems.map((item, index) => (
          <a
            key={index}
            href="#"
            className={`flex items-center p-3 rounded-lg transition-colors group relative ${
              index === 0
                ? 'bg-[var(--color-accent)]/10 text-[var(--color-accent)] font-bold'
                : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-light)]/50 hover:text-white'
            }`}
          >
             {index === 0 && <div className="absolute left-0 h-6 w-1 bg-[var(--color-accent)] rounded-r-full"></div>}
            {item.icon}
            <span className="mr-4 hidden md:inline">{item.name}</span>
          </a>
        ))}
      </nav>
      <div className="mt-auto w-full">
        {/* User profile or other bottom items can go here */}
      </div>
    </aside>
  );
};

export default Sidebar;