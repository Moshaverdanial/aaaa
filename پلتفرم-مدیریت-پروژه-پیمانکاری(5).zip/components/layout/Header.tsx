import React from 'react';
import { UserType } from '../../types';
import { LogoutIcon, ChevronLeftIcon } from '../icons/Icons';

interface HeaderProps {
  userType: UserType;
  onLogout: () => void;
  onBack?: () => void;
}

const Header: React.FC<HeaderProps> = ({ userType, onLogout, onBack }) => {
  return (
    <header className="flex-shrink-0 bg-[var(--color-surface)]/80 backdrop-blur-sm border-b border-[var(--color-border)] px-4 sm:px-6 md:px-8 py-4 flex items-center justify-between">
      <div className="flex items-center">
        {onBack && (
          <button onClick={onBack} className="text-[var(--color-text-secondary)] hover:text-[var(--color-accent)] transition-colors ml-4 p-2 rounded-full hover:bg-[var(--color-background)] group">
            <ChevronLeftIcon />
            <span className="sr-only">Back</span>
          </button>
        )}
        <h1 className="text-lg font-semibold text-[var(--color-text-primary)]">
          {onBack ? 'جزئیات پروژه' : 'داشبورد پروژه ها'}
        </h1>
      </div>
      <div className="flex items-center space-x-4 space-x-reverse">
        <span className="text-sm text-[var(--color-text-secondary)]">
          خوش آمدید، <span className="font-bold text-white">{userType}</span>
        </span>
        <button
          onClick={onLogout}
          className="flex items-center text-[var(--color-text-secondary)] hover:text-red-400 transition-colors p-2 rounded-lg hover:bg-[var(--color-background)]"
          title="خروج"
        >
          <LogoutIcon />
          <span className="mr-2 hidden sm:inline">خروج</span>
        </button>
      </div>
    </header>
  );
};

export default Header;