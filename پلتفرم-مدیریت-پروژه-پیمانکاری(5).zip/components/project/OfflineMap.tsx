import React, { useState, useEffect, useRef } from 'react';
import { Plot } from '../../types';
import { TrashIcon } from '../icons/Icons';

const usePersistentState = (key: string, defaultValue: Plot[]): [Plot[], React.Dispatch<React.SetStateAction<Plot[]>>] => {
  const [state, setState] = useState<Plot[]>(() => {
    try {
      const storedValue = localStorage.getItem(key);
      return storedValue ? JSON.parse(storedValue) : defaultValue;
    } catch (error) {
      console.error("Error reading from localStorage", error);
      return defaultValue;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(state));
    } catch (error) {
      console.error("Error writing to localStorage", error);
    }
  }, [key, state]);

  return [state, setState];
};

const OfflineMap: React.FC = () => {
    const [plots, setPlots] = usePersistentState('kangan-plots', []);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [newPlotCoords, setNewPlotCoords] = useState<{x: number, y: number} | null>(null);
    const [editingPlot, setEditingPlot] = useState<Plot | null>(null);
    const [plotNumberInput, setPlotNumberInput] = useState('');
    const mapContainerRef = useRef<HTMLDivElement>(null);

    const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!mapContainerRef.current) return;
        const rect = mapContainerRef.current.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;
        setNewPlotCoords({ x, y });
        setEditingPlot(null);
        setPlotNumberInput('');
        setIsModalOpen(true);
    };

    const handleEditClick = (plot: Plot, e: React.MouseEvent) => {
        e.stopPropagation(); // Prevent map click from firing
        setEditingPlot(plot);
        setPlotNumberInput(plot.plotNumber);
        setNewPlotCoords(null);
        setIsModalOpen(true);
    };
    
    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingPlot(null);
        setNewPlotCoords(null);
        setPlotNumberInput('');
    }

    const handleSave = () => {
        if (plotNumberInput.trim()) {
            if (editingPlot) {
                // Edit existing plot
                setPlots(plots.map(p => p.id === editingPlot.id ? { ...p, plotNumber: plotNumberInput } : p));
            } else if (newPlotCoords) {
                // Add new plot
                const newPlot: Plot = {
                    id: `PLOT-${Date.now()}`,
                    plotNumber: plotNumberInput,
                    x: newPlotCoords.x,
                    y: newPlotCoords.y
                };
                setPlots([...plots, newPlot]);
            }
            handleCloseModal();
        }
    };

    const handleDeletePlot = (id: string) => {
        if (window.confirm('آیا از حذف این پلاک اطمینان دارید؟')) {
            setPlots(plots.filter(p => p.id !== id));
        }
    };

    return (
        <div>
            <h3 className="text-xl font-semibold text-[var(--color-text-primary)] mb-4">نقشه آفلاین کنگان</h3>
            <p className="text-[var(--color-text-secondary)] mb-6">
                برای افزودن پلاک جدید، روی نقطه مورد نظر در نقشه کلیک کنید. برای ویرایش، روی پلاک موجود کلیک کنید.
            </p>

            <div className="flex flex-col md:flex-row gap-8">
                {/* Map Area */}
                <div className="w-full md:w-3/4">
                    <div
                        ref={mapContainerRef}
                        onClick={handleMapClick}
                        className="relative w-full aspect-[4/3] bg-[var(--color-background)] rounded-lg cursor-crosshair border-2 border-[var(--color-border)] overflow-hidden"
                    >
                        <img 
                            src="https://picsum.photos/seed/kangan-map/1200/900" 
                            alt="نقشه شهر کنگان"
                            className="w-full h-full object-cover"
                        />
                        {/* Render saved plots */}
                        {plots.map((plot, index) => (
                             <div
                                key={plot.id}
                                onClick={(e) => handleEditClick(plot, e)}
                                className="absolute w-4 h-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[var(--color-accent)] border-2 border-white shadow-lg cursor-pointer group animate-popIn"
                                style={{ 
                                    left: `${plot.x}%`, 
                                    top: `${plot.y}%`,
                                    animationDelay: `${index * 30}ms`
                                }}
                                title={`پلاک: ${plot.plotNumber}`}
                            >
                               <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 w-max bg-black text-white text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    پلاک: {plot.plotNumber}
                               </span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Plot List */}
                <div className="w-full md:w-1/4">
                    <h4 className="font-bold text-lg mb-4">پلاک‌های ذخیره شده</h4>
                    <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                        {plots.length > 0 ? (
                            plots.map(plot => (
                                <div key={plot.id} className="flex justify-between items-center bg-[var(--color-surface)] p-3 rounded-md">
                                    <span className="font-semibold">{plot.plotNumber}</span>
                                    <button onClick={() => handleDeletePlot(plot.id)} className="text-gray-400 hover:text-red-400">
                                        <TrashIcon />
                                    </button>
                                </div>
                            ))
                        ) : (
                            <p className="text-[var(--color-text-secondary)]">هیچ پلاکی ذخیره نشده است.</p>
                        )}
                    </div>
                </div>
            </div>

            {/* Add/Edit Plot Modal */}
            {isModalOpen && (
                 <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 animate-scaleIn">
                    <div className="bg-slate-800/50 backdrop-blur-xl p-6 rounded-lg shadow-xl w-full max-w-sm m-4 border border-white/20">
                        <h4 className="text-lg font-bold mb-4 text-white">{editingPlot ? 'ویرایش شماره پلاک' : 'افزودن شماره پلاک'}</h4>
                        <div>
                            <label htmlFor="plotNumber" className="block text-sm font-medium text-[var(--color-text-secondary)] mb-1">شماره پلاک</label>
                            <input
                                type="text"
                                id="plotNumber"
                                value={plotNumberInput}
                                onChange={(e) => setPlotNumberInput(e.target.value)}
                                className="w-full bg-[var(--color-background)] border border-[var(--color-border)] rounded-md px-3 py-2 focus:ring-1 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                                autoFocus
                            />
                        </div>
                        <div className="mt-6 flex justify-end space-x-3 space-x-reverse">
                            <button onClick={handleCloseModal} className="px-4 py-2 rounded-md text-[var(--color-text-secondary)] hover:bg-[var(--color-background)]">انصراف</button>
                            <button onClick={handleSave} className="px-4 py-2 rounded-md bg-gradient-to-br from-[var(--color-accent)] to-[var(--color-accent-hover)] text-white font-bold">ذخیره</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default OfflineMap;