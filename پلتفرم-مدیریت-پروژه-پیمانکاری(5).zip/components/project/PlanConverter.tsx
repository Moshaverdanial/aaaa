import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { generate3dView } from '../../services/geminiService';
import Spinner from '../common/Spinner';
import { UploadIcon, DownloadIcon } from '../icons/Icons';

const PlanConverter: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles && acceptedFiles.length > 0) {
      const selectedFile = acceptedFiles[0];
      setFile(selectedFile);
      const previewUrl = URL.createObjectURL(selectedFile);
      setPreview(previewUrl);
      setGeneratedImage(null);
      setError(null);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': ['.jpeg', '.png', '.jpg'] },
    multiple: false,
  });

  const handleGenerate = async () => {
    if (!file) {
      setError('لطفا ابتدا یک فایل انتخاب کنید.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);
    try {
      const result = await generate3dView(file);
      setGeneratedImage(result);
    } catch (err: any) {
      setError(err.message || 'یک خطای ناشناخته رخ داد.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleDownload = () => {
    if (generatedImage) {
      const link = document.createElement('a');
      link.href = generatedImage;
      const timestamp = Date.now();
      link.download = `project-3d-view-${timestamp}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };


  return (
    <div>
      <h3 className="text-xl font-semibold text-[var(--color-text-primary)] mb-4">تبدیل نقشه دو بعدی به رندر سه بعدی</h3>
      <p className="text-[var(--color-text-secondary)] mb-6">نقشه دو بعدی خود را بارگذاری کنید تا هوش مصنوعی یک رندر سه بعدی فتورئالیستی برای شما ایجاد کند.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
        {/* Upload and Preview */}
        <div>
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
              isDragActive ? 'border-[var(--color-accent)] bg-[var(--color-background)]' : 'border-[var(--color-border)] hover:border-[var(--color-accent)]'
            }`}
          >
            <input {...getInputProps()} />
            <div className="flex flex-col items-center">
              <UploadIcon />
              {isDragActive ? (
                <p className="mt-2 text-[var(--color-text-primary)]">فایل را اینجا رها کنید...</p>
              ) : (
                <p className="mt-2 text-[var(--color-text-secondary)]">فایل نقشه را بکشید و رها کنید، یا برای انتخاب کلیک کنید</p>
              )}
              <p className="text-xs text-gray-500 mt-1">PNG, JPG, JPEG</p>
            </div>
          </div>
          {preview && (
            <div className="mt-4">
              <h4 className="font-semibold text-[var(--color-text-primary)] mb-2">پیش‌نمایش نقشه:</h4>
              <img src={preview} alt="Preview" className="rounded-lg max-w-full h-auto" />
            </div>
          )}
          <button
            onClick={handleGenerate}
            disabled={!file || isLoading}
            className="mt-6 w-full bg-gradient-to-r from-[var(--color-accent)] to-cyan-400 text-slate-900 font-bold py-3 px-4 rounded-lg transition-all duration-300 ease-in-out transform hover:scale-105 hover:shadow-[0_0_20px_var(--color-accent)] disabled:from-slate-500 disabled:to-slate-600 disabled:text-slate-400 disabled:shadow-none disabled:scale-100 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isLoading ? <Spinner /> : 'ایجاد رندر سه بعدی'}
          </button>
        </div>

        {/* Generated Image Display */}
        <div className="flex flex-col items-center justify-center bg-[var(--color-background)] p-4 rounded-lg min-h-[300px]">
          {isLoading && (
            <div className="text-center animate-fadeIn">
              <Spinner large />
              <p className="mt-4 text-[var(--color-text-secondary)] animate-pulse">در حال ایجاد رندر... این فرآیند ممکن است کمی طول بکشد.</p>
            </div>
          )}
          {error && <p className="text-red-400 text-center animate-fadeIn">{error}</p>}
          {generatedImage && !isLoading && (
            <div className="w-full text-center animate-fadeIn">
              <img src={generatedImage} alt="Generated 3D View" className="rounded-lg shadow-2xl mb-4" />
              <button 
                onClick={handleDownload} 
                className="inline-flex items-center justify-center bg-gradient-to-r from-[var(--color-accent)] to-cyan-400 text-slate-900 px-6 py-2 rounded-lg font-bold transition-all hover:scale-105"
              >
                  <DownloadIcon/>
                  <span className="mr-2">دانلود تصویر</span>
              </button>
            </div>
          )}
          {!isLoading && !generatedImage && !error && (
            <p className="text-gray-500 animate-fadeIn">رندر سه بعدی شما در اینجا نمایش داده خواهد شد.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default PlanConverter;