import React from 'react';

const AboutUs: React.FC = () => {
  return (
    <div className="flex flex-col md:flex-row items-center gap-8 text-center md:text-right">
      <div className="w-full md:w-1/3 flex-shrink-0 p-1 bg-gradient-to-br from-[var(--color-accent)] to-[var(--color-accent-hover)] rounded-full">
        <img 
          src="https://images.unsplash.com/photo-1556157382-97eda2d62296?q=80&w=2670&auto=format&fit=crop" 
          alt="مدیر شرکت"
          className="rounded-full w-48 h-48 mx-auto md:mx-0 object-cover border-4 border-[var(--color-surface)]"
        />
      </div>
      <div className="w-full md:w-2/3">
        <h3 className="text-2xl font-bold text-white mb-4">درباره ما</h3>
        <p className="text-[var(--color-text-secondary)] leading-loose mb-4">
          ما یک شرکت پیشرو در زمینه طراحی و معماری مدرن هستیم که با بهره‌گیری از جدیدترین فناوری‌ها و تیمی از متخصصان خلاق، رویاهای شما را به واقعیت تبدیل می‌کنیم.
        </p>
        <p className="text-[var(--color-text-secondary)] leading-loose">
          تعهد ما به کیفیت، نوآوری و رضایت مشتری، سنگ بنای تمامی پروژه‌های ماست. از طراحی اولیه تا اجرای نهایی، در هر قدم همراه شما هستیم تا فضایی بی‌نظیر و ماندگار خلق کنیم.
        </p>
      </div>
    </div>
  );
};

export default AboutUs;