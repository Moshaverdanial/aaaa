import React, { useState, useEffect, useRef } from 'react';
import { Project, UserType, ChatMessage } from '../../types';
import { generateChatResponse } from '../../services/geminiService';
import { SendIcon, SparklesIcon } from '../icons/Icons';

const usePersistentState = <T,>(key: string, defaultValue: T): [T, React.Dispatch<React.SetStateAction<T>>] => {
  const [state, setState] = useState<T>(() => {
    try {
      const storedValue = localStorage.getItem(key);
      return storedValue ? JSON.parse(storedValue) : defaultValue;
    } catch (error) {
      console.error("Error reading from localStorage", error);
      return defaultValue;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(state));
    } catch (error) {
      console.error("Error writing to localStorage", error);
    }
  }, [key, state]);

  return [state, setState];
};


interface ChatViewProps {
  project: Project;
  userType: UserType;
}

const ChatView: React.FC<ChatViewProps> = ({ project, userType }) => {
  const [messages, setMessages] = usePersistentState<ChatMessage[]>(`chat-history-${project.id}`, []);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    if (messages.length === 0) {
        const welcomeMessage: ChatMessage = {
            id: `msg-welcome-${Date.now()}`,
            text: `سلام! من دستیار هوشمند پروژه شما هستم. چطور می‌توانم در مورد پروژه "${project.name}" به شما کمک کنم؟`,
            sender: 'ai',
            timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages([welcomeMessage]);
    }
  }, []);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() === '' || isLoading) return;

    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      text: input,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
      const aiResponseText = await generateChatResponse(project, userType, newMessages, input);
      const aiMessage: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        text: aiResponseText,
        sender: 'ai',
        timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error(error);
      const errorMessage: ChatMessage = {
        id: `msg-error-${Date.now()}`,
        text: 'متاسفانه خطایی رخ داد. لطفا دوباره تلاش کنید.',
        sender: 'ai',
        timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
        <h3 className="text-xl font-semibold text-[var(--color-text-primary)] mb-4 flex items-center">
            <SparklesIcon className="w-6 h-6 ml-2 text-[var(--color-accent)]" />
            دستیار هوشمند پروژه
        </h3>
        <p className="text-[var(--color-text-secondary)] mb-6">
            می‌توانید سوالات خود را در مورد وضعیت، بودجه و جزئیات پروژه از دستیار هوشمند ما بپرسید.
        </p>

        <div className="bg-[var(--color-background)] rounded-lg border border-[var(--color-border)] p-4 flex flex-col h-[50vh]">
            <div className="flex-1 overflow-y-auto space-y-4 pr-2">
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex items-end gap-3 animate-fadeInUp ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                       {msg.sender === 'ai' && <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[var(--color-accent)] to-cyan-500 flex items-center justify-center flex-shrink-0"><SparklesIcon className="w-5 h-5 text-slate-900"/></div>}
                       <div className={`max-w-xl p-3 rounded-2xl ${msg.sender === 'user' ? 'bg-gradient-to-br from-[var(--color-accent)] to-cyan-500 text-slate-900 rounded-br-none' : 'bg-[var(--color-surface-light)] rounded-bl-none'}`}>
                            <p className="text-sm leading-relaxed">{msg.text}</p>
                            <p className={`text-xs mt-2 text-right opacity-70 ${msg.sender === 'user' ? 'text-slate-800' : 'text-[var(--color-text-secondary)]'}`}>{msg.timestamp}</p>
                       </div>
                    </div>
                ))}

                {isLoading && (
                    <div className="flex items-end gap-3 justify-start animate-fadeInUp">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[var(--color-accent)] to-cyan-500 flex items-center justify-center flex-shrink-0"><SparklesIcon className="w-5 h-5 text-slate-900"/></div>
                        <div className="max-w-md p-3 rounded-2xl bg-[var(--color-surface-light)] rounded-bl-none">
                            <div className="flex items-center space-x-1 space-x-reverse">
                                <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse"></span>
                                <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: '200ms' }}></span>
                                <span className="w-2 h-2 bg-slate-400 rounded-full animate-pulse" style={{ animationDelay: '400ms' }}></span>
                            </div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSend} className="mt-4 flex items-center gap-3 border-t border-[var(--color-border)] pt-4">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="پیام خود را بنویسید..."
                    className="flex-1 bg-[var(--color-surface)] border border-[var(--color-border)] rounded-full px-4 py-2.5 focus:ring-1 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)] transition-colors"
                    disabled={isLoading}
                    aria-label="ورودی پیام"
                />
                <button
                    type="submit"
                    className="bg-[var(--color-accent)] hover:bg-[var(--color-accent-hover)] text-slate-900 rounded-full p-3 transition-all transform hover:scale-110 disabled:bg-slate-600 disabled:scale-100 disabled:cursor-not-allowed"
                    disabled={isLoading || input.trim() === ''}
                    aria-label="ارسال پیام"
                >
                    <SendIcon />
                </button>
            </form>
        </div>
    </div>
  );
};

export default ChatView;
