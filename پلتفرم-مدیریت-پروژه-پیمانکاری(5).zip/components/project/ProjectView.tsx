import React, { useState } from 'react';
import { Project, UserType } from '../../types';
import Tabs from '../common/Tabs';
import PlanConverter from './PlanConverter';
import VirtualTour from './VirtualTour';
import AccountingView from './AccountingView';
import AboutUs from './AboutUs';
import OfflineMap from './OfflineMap';
import ProjectShareModal from './ProjectShareModal';
import ChatView from './ChatView';
import { ShareIcon } from '../icons/Icons';

interface ProjectViewProps {
  project: Project;
  userType: UserType;
}

const ProjectView: React.FC<ProjectViewProps> = ({ project, userType }) => {
  const [activeTab, setActiveTab] = useState('گفتگو');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  const baseTabs = ['گفتگو', 'تبدیل نقشه', 'تور مجازی', 'حسابداری', 'درباره ما'];
  const tabs = userType === UserType.Colleague ? [...baseTabs, 'نقشه آفلاین'] : baseTabs;

  const renderContent = () => {
    switch (activeTab) {
      case 'گفتگو':
        return <ChatView project={project} userType={userType} />;
      case 'تبدیل نقشه':
        return <PlanConverter />;
      case 'تور مجازی':
        return <VirtualTour />;
      case 'حسابداری':
        return <AccountingView projectId={project.id} />;
      case 'درباره ما':
        return <AboutUs />;
      case 'نقشه آفلاین':
        return userType === UserType.Colleague ? <OfflineMap /> : null;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">{project.name}</h2>
          <p className="text-[var(--color-text-secondary)]">مشتری: {project.client}</p>
        </div>
        <button
          onClick={() => setIsShareModalOpen(true)}
          className="flex items-center space-x-2 space-x-reverse bg-[var(--color-surface)] hover:bg-[var(--color-surface-light)] border border-[var(--color-border)] text-[var(--color-text-secondary)] hover:text-[var(--color-accent)] font-semibold py-2 px-4 rounded-lg transition-colors"
          aria-label="اشتراک گذاری پروژه"
        >
          <ShareIcon />
          <span className="hidden sm:inline">اشتراک گذاری</span>
        </button>
      </div>

      <Tabs tabs={tabs} activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <div className="mt-6 bg-[var(--color-surface)]/80 backdrop-blur-sm border border-[var(--color-border)] p-6 rounded-lg shadow-lg">
        <div key={activeTab} className="animate-fadeInUp">
          {renderContent()}
        </div>
      </div>

      {isShareModalOpen && (
        <ProjectShareModal
          project={project}
          userType={userType}
          onClose={() => setIsShareModalOpen(false)}
        />
      )}
    </div>
  );
};

export default ProjectView;