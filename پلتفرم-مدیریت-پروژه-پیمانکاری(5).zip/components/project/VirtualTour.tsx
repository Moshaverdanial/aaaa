
import React, { useState, useEffect, useRef } from 'react';
import { ZoomInIcon, ZoomOutIcon, ExpandIcon, CloseIcon, ChevronLeftIcon, ChevronRightIcon } from '../icons/Icons';

const images = [
  "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=2600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1616046229478-9901c5536a45?q=80&w=2600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1615874959474-d609969a20ed?q=80&w=2600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1617806118233-18e1de247200?q=80&w=2600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1598928636135-d146006a9a5a?q=80&w=2600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?q=80&w=2600&auto=format&fit=crop",
];

const VirtualTour: React.FC = () => {
    const [mainImageIndex, setMainImageIndex] = useState(0);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [zoom, setZoom] = useState(1);
    const [pan, setPan] = useState({ x: 0, y: 0 });
    const isPanning = useRef(false);
    const startPan = useRef({ x: 0, y: 0 });
    const imageRef = useRef<HTMLImageElement>(null);

    const handleNext = () => {
        setMainImageIndex((prev) => (prev + 1) % images.length);
        resetZoomAndPan();
    };

    const handlePrev = () => {
        setMainImageIndex((prev) => (prev - 1 + images.length) % images.length);
        resetZoomAndPan();
    };

    const resetZoomAndPan = () => {
        setZoom(1);
        setPan({ x: 0, y: 0 });
    };
    
    const handleZoomIn = () => setZoom(prev => Math.min(prev * 1.2, 5));
    const handleZoomOut = () => setZoom(prev => Math.max(prev / 1.2, 1));
    
    const onMouseDown = (e: React.MouseEvent) => {
        if (zoom > 1) {
            isPanning.current = true;
            startPan.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
            if (imageRef.current) imageRef.current.style.cursor = 'grabbing';
        }
    };
    
    const onMouseMove = (e: React.MouseEvent) => {
        if (isPanning.current && imageRef.current) {
            const newX = e.clientX - startPan.current.x;
            const newY = e.clientY - startPan.current.y;
            
            const rect = imageRef.current.getBoundingClientRect();
            const maxPanX = (rect.width * zoom - rect.width) / 2;
            const maxPanY = (rect.height * zoom - rect.height) / 2;

            setPan({
                x: Math.max(-maxPanX, Math.min(maxPanX, newX)),
                y: Math.max(-maxPanY, Math.min(maxPanY, newY))
            });
        }
    };
    
    const onMouseUp = () => {
        isPanning.current = false;
        if (imageRef.current) imageRef.current.style.cursor = 'grab';
    };

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (isFullscreen) {
                if (e.key === 'Escape') setIsFullscreen(false);
                if (e.key === 'ArrowRight') handleNext();
                if (e.key === 'ArrowLeft') handlePrev();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isFullscreen, mainImageIndex]);

  return (
    <div role="region" aria-label="تور مجازی پروژه">
      <h3 className="text-xl font-semibold text-[var(--color-text-primary)] mb-4">تور مجازی</h3>
      <p className="text-[var(--color-text-secondary)] mb-6">
        در این فضا به صورت مجازی قدم بزنید و جزئیات طراحی را از نزدیک مشاهده کنید.
      </p>

      <div className="relative group">
        <img 
          key={mainImageIndex}
          src={images[mainImageIndex]}
          alt={`نمای اصلی پروژه - تصویر ${mainImageIndex + 1} از ${images.length}`}
          className="w-full aspect-video object-cover rounded-lg cursor-pointer border border-[var(--color-border)] animate-fadeIn"
          onClick={() => setIsFullscreen(true)}
        />
        <div 
          onClick={() => setIsFullscreen(true)}
          className="absolute inset-0 bg-black/20 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
        >
          <ExpandIcon className="w-16 h-16 text-white drop-shadow-lg" />
        </div>
      </div>
      
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 mt-4">
        {images.map((img, index) => (
          <img
            key={index}
            src={img}
            alt={`تصویر کوچک ${index + 1} از ${images.length}`}
            className={`w-full aspect-square object-cover rounded-md cursor-pointer transition-all border-2 ${
              mainImageIndex === index ? 'border-[var(--color-accent)]' : 'border-transparent hover:border-[var(--color-accent)]'
            }`}
            onClick={() => setMainImageIndex(index)}
          />
        ))}
      </div>

      {isFullscreen && (
        <div className="fixed inset-0 bg-black/90 z-50 flex flex-col items-center justify-center animate-fadeInDown" onMouseMove={onMouseMove} onMouseUp={onMouseUp}>
           <h2 className="sr-only">نمایش تمام صفحه تصویر</h2>
           <div 
            className="w-full h-full flex items-center justify-center overflow-hidden"
            onMouseDown={onMouseDown}
           >
                <img
                    ref={imageRef} 
                    key={mainImageIndex}
                    src={images[mainImageIndex]}
                    alt={`تصویر تمام صفحه ${mainImageIndex + 1} از ${images.length}`}
                    className="max-w-full max-h-full object-contain transition-transform duration-200 ease-out animate-fadeIn"
                    style={{ 
                        transform: `scale(${zoom}) translateX(${pan.x}px) translateY(${pan.y}px)`,
                        cursor: zoom > 1 ? 'grab' : 'auto'
                    }}
                />
            </div>
          
            {/* Controls */}
            <button onClick={() => setIsFullscreen(false)} className="absolute top-4 right-4 text-white hover:text-[var(--color-accent)] transition-colors p-2"><CloseIcon /></button>
            <button onClick={handlePrev} className="absolute left-4 top-1/2 -translate-y-1/2 text-white hover:text-[var(--color-accent)] transition-colors p-2 bg-black/30 rounded-full"><ChevronLeftIcon /></button>
            <button onClick={handleNext} className="absolute right-4 top-1/2 -translate-y-1/2 text-white hover:text-[var(--color-accent)] transition-colors p-2 bg-black/30 rounded-full"><ChevronRightIcon /></button>

            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center space-x-2 space-x-reverse bg-black/50 p-2 rounded-lg" aria-live="polite">
                <button onClick={handleZoomOut} className="text-white p-2 hover:text-[var(--color-accent)] rounded-md transition-colors" aria-label="کوچک‌نمایی"><ZoomOutIcon /></button>
                <button onClick={resetZoomAndPan} className="text-white p-2 hover:text-[var(--color-accent)] rounded-md transition-colors" aria-label="بازنشانی زوم">بازنشانی</button>
                <button onClick={handleZoomIn} className="text-white p-2 hover:text-[var(--color-accent)] rounded-md transition-colors" aria-label="بزرگ‌نمایی"><ZoomInIcon /></button>
                 <span className="text-white text-sm w-16 text-center">{(zoom * 100).toFixed(0)}%</span>
            </div>
        </div>
      )}
    </div>
  );
};

export default VirtualTour;