import React, { useState, useEffect } from 'react';
import { Project, UserType } from '../../types';
import { generateProjectSummary } from '../../services/geminiService';
import Modal from '../common/Modal';
import Spinner from '../common/Spinner';
import { ClipboardIcon } from '../icons/Icons';

interface ProjectShareModalProps {
  project: Project;
  userType: UserType;
  onClose: () => void;
}

const ProjectShareModal: React.FC<ProjectShareModalProps> = ({ project, userType, onClose }) => {
  const [summary, setSummary] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);

  useEffect(() => {
    const fetchSummary = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const generatedSummary = await generateProjectSummary(project, userType);
        setSummary(generatedSummary);
      } catch (err: any) {
        setError(err.message || 'An unknown error occurred.');
      } finally {
        setIsLoading(false);
      }
    };
    fetchSummary();
  }, [project, userType]);

  const handleCopy = () => {
    const fullTextToCopy = `خلاصه پروژه: ${project.name}\n\n${summary}`;
    navigator.clipboard.writeText(fullTextToCopy).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000); // Reset after 2 seconds
    });
  };

  return (
    <Modal isOpen={true} onClose={onClose} title="اشتراک گذاری خلاصه پروژه">
      <div className="min-h-[150px] flex flex-col">
        {isLoading && (
          <div className="flex-1 flex flex-col items-center justify-center">
            <Spinner large />
            <p className="mt-4 text-[var(--color-text-secondary)]">در حال آماده سازی خلاصه...</p>
          </div>
        )}
        {error && (
          <div className="flex-1 flex items-center justify-center text-red-400">
            <p>{error}</p>
          </div>
        )}
        {!isLoading && !error && summary && (
          <div className="flex-1 flex flex-col">
            <p className="bg-black/20 p-4 rounded-md text-[var(--color-text-secondary)] whitespace-pre-wrap flex-1">
              {summary}
            </p>
            <div className="mt-6 flex justify-end">
              <button 
                onClick={handleCopy}
                className="flex items-center justify-center bg-gradient-to-r from-[var(--color-accent)] to-cyan-400 text-slate-900 font-bold py-2 px-4 rounded-lg transition-all hover:scale-105"
              >
                <ClipboardIcon />
                <span className="mr-2">{isCopied ? 'کپی شد!' : 'کپی در کلیپ‌بورد'}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};

export default ProjectShareModal;