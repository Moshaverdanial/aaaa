import React, { useState, useEffect } from 'react';
import { Invoice } from '../../types';
import { PlusIcon, PencilIcon, TrashIcon } from '../icons/Icons';
import Modal from '../common/Modal';

const usePersistentState = (key: string, defaultValue: Invoice[]): [Invoice[], React.Dispatch<React.SetStateAction<Invoice[]>>] => {
  const [state, setState] = useState<Invoice[]>(() => {
    try {
      const storedValue = localStorage.getItem(key);
      return storedValue ? JSON.parse(storedValue) : defaultValue;
    } catch (error) {
      console.error("Error reading from localStorage", error);
      return defaultValue;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(state));
    } catch (error) {
      console.error("Error writing to localStorage", error);
    }
  }, [key, state]);

  return [state, setState];
};

const initialInvoices: Invoice[] = [
    { id: 'INV-001', description: 'هزینه فاز اول طراحی', date: '۱۴۰۳/۰۳/۰۱', amount: 15000000, status: 'پرداخت شده' },
    { id: 'INV-002', description: 'خرید مصالح اولیه', date: '۱۴۰۳/۰۳/۱۵', amount: 75000000, status: 'پرداخت شده' },
    { id: 'INV-003', description: 'پیش پرداخت پیمانکار', date: '۱۴۰۳/۰۴/۰۵', dueDate: '۱۴۰۳/۰۴/۱۵', amount: 50000000, status: 'در انتظار پرداخت' },
    { id: 'INV-004', description: 'هزینه نظارت', date: '۱۴۰۳/۰۴/۲۰', dueDate: '۱۴۰۳/۰۴/۳۰', amount: 12500000, status: 'در انتظار پرداخت' },
];

const AccountingView: React.FC<{ projectId: number }> = ({ projectId }) => {
    // Use a project-specific key for storing invoices
    const [invoices, setInvoices] = usePersistentState(`project-invoices-${projectId}`, projectId === 1 ? initialInvoices : []);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentInvoice, setCurrentInvoice] = useState<Partial<Invoice> | null>(null);
    const [errors, setErrors] = useState<{ description?: string; amount?: string }>({});

    const handleOpenModal = (invoice?: Invoice) => {
        setCurrentInvoice(invoice || { description: '', amount: 0, status: 'در انتظار پرداخت', date: new Date().toLocaleDateString('fa-IR-u-nu-latn').replace(/\//g, '/'), dueDate: '' });
        setIsModalOpen(true);
        setErrors({});
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setCurrentInvoice(null);
    };

    const validateForm = () => {
        const newErrors: { description?: string; amount?: string } = {};
        if (!currentInvoice?.description?.trim()) {
            newErrors.description = 'توضیحات نمی‌تواند خالی باشد.';
        }
        if (!currentInvoice?.amount || currentInvoice.amount <= 0) {
            newErrors.amount = 'مبلغ باید یک عدد مثبت باشد.';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSaveInvoice = () => {
        if (!validateForm()) return;

        if (currentInvoice?.id) { // Edit
            setInvoices(invoices.map(inv => inv.id === currentInvoice.id ? currentInvoice as Invoice : inv));
        } else { // Add
            const newInvoice: Invoice = {
                ...currentInvoice,
                id: `INV-${Date.now()}`,
                date: new Date().toLocaleDateString('fa-IR-u-nu-latn').replace(/\//g, '/'),
            } as Invoice;
            setInvoices([newInvoice, ...invoices]);
        }
        handleCloseModal();
    };

    const handleDelete = (id: string) => {
        if (window.confirm('آیا از حذف این فاکتور اطمینان دارید؟')) {
            setInvoices(prev => prev.map(inv => inv.id === id ? { ...inv, isDeleting: true } : inv));
            setTimeout(() => {
                setInvoices(prev => prev.filter(inv => inv.id !== id));
            }, 500);
        }
    };
    
    const totalAmount = invoices.reduce((sum, inv) => sum + inv.amount, 0);
    const paidAmount = invoices.filter(inv => inv.status === 'پرداخت شده').reduce((sum, inv) => sum + inv.amount, 0);
    const unpaidAmount = totalAmount - paidAmount;

    const StatusBadge: React.FC<{ status: 'پرداخت شده' | 'در انتظار پرداخت' }> = ({ status }) => {
        const isPaid = status === 'پرداخت شده';
        return (
            <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-opacity-10 ${isPaid ? 'bg-emerald-500 text-emerald-400' : 'bg-amber-500 text-amber-400'}`}>
                <span className={`w-2 h-2 mr-1.5 rounded-full ${isPaid ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
                {status}
            </div>
        );
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-semibold text-[var(--color-text-primary)]">نمای حسابداری و فاکتورها</h3>
                <button
                    onClick={() => handleOpenModal()}
                    className="flex items-center bg-gradient-to-r from-[var(--color-accent)] to-cyan-400 text-slate-900 font-bold py-2 px-4 rounded-lg transition-transform hover:scale-105"
                >
                    <PlusIcon />
                    <span className="mr-2">افزودن فاکتور</span>
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 text-[var(--color-text-primary)]">
                <div className="bg-gradient-to-br from-[var(--color-surface)] to-slate-800 p-5 rounded-lg border border-[var(--color-border)] shadow-lg">
                    <h4 className="text-sm font-medium text-[var(--color-text-secondary)]">جمع کل</h4>
                    <p className="text-2xl font-bold mt-1">{totalAmount.toLocaleString('fa-IR')} تومان</p>
                </div>
                <div className="bg-gradient-to-br from-emerald-900/50 to-[var(--color-surface)] p-5 rounded-lg border border-emerald-500/30 shadow-lg">
                    <h4 className="text-emerald-400">پرداخت شده</h4>
                    <p className="text-2xl font-bold mt-1 text-white">{paidAmount.toLocaleString('fa-IR')} تومان</p>
                </div>
                <div className="bg-gradient-to-br from-amber-900/50 to-[var(--color-surface)] p-5 rounded-lg border border-amber-500/30 shadow-lg">
                    <h4 className="text-amber-400">بدهی</h4>
                    <p className="text-2xl font-bold mt-1 text-white">{unpaidAmount.toLocaleString('fa-IR')} تومان</p>
                </div>
            </div>

            <div className="space-y-3">
                {invoices.length > 0 ? invoices.map(invoice => (
                    <div
                        key={invoice.id}
                        className={`flex flex-col md:flex-row items-start md:items-center p-4 rounded-lg transition-all duration-500 bg-[var(--color-surface)]/50 hover:bg-[var(--color-surface-light)]/60 border border-[var(--color-border)] hover:border-[var(--color-accent)]/50 group ${
                            invoice.isDeleting ? 'animate-fadeOutShrink' : 'animate-fadeInDown'
                        }`}
                    >
                        <div className="w-full md:w-1/4 mb-2 md:mb-0">
                            <p className="text-sm text-[var(--color-text-secondary)]">کد: {invoice.id}</p>
                            <p className="font-bold text-[var(--color-text-primary)]">{invoice.description}</p>
                        </div>
                        <div className="w-full md:w-1/4 text-sm mb-2 md:mb-0">
                            <p className="text-[var(--color-text-secondary)]">تاریخ صدور: {invoice.date}</p>
                             {invoice.dueDate && (
                                <p className="text-amber-400/80">تاریخ سررسید: {invoice.dueDate}</p>
                            )}
                        </div>
                        <div className="w-full md:w-1/4 font-semibold text-lg text-[var(--color-text-primary)] mb-2 md:mb-0">{invoice.amount.toLocaleString('fa-IR')} تومان</div>
                        <div className="w-full md:w-1/4 mb-2 md:mb-0"><StatusBadge status={invoice.status} /></div>
                        <div className="w-full md:w-auto flex items-center justify-end space-x-2 space-x-reverse opacity-50 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => handleOpenModal(invoice)} className="text-[var(--color-text-secondary)] hover:text-[var(--color-accent)] transition-colors p-1"><PencilIcon /></button>
                            <button onClick={() => handleDelete(invoice.id)} className="text-[var(--color-text-secondary)] hover:text-red-400 transition-colors p-1"><TrashIcon /></button>
                        </div>
                    </div>
                )) : (
                    <div className="text-center py-10">
                        <p className="text-[var(--color-text-secondary)]">هنوز هیچ فاکتوری برای این پروژه ثبت نشده است.</p>
                    </div>
                )}
            </div>

            <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={currentInvoice?.id ? 'ویرایش فاکتور' : 'افزودن فاکتور جدید'}>
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-1">توضیحات</label>
                        <input
                            type="text"
                            value={currentInvoice?.description || ''}
                            onChange={(e) => setCurrentInvoice({ ...currentInvoice, description: e.target.value })}
                            className="w-full bg-[var(--color-background)] border border-[var(--color-border)] rounded-md px-3 py-2 focus:ring-1 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                        />
                        {errors.description && <p className="text-red-400 text-xs mt-1">{errors.description}</p>}
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-1">مبلغ (تومان)</label>
                        <input
                            type="number"
                            value={currentInvoice?.amount || ''}
                            onChange={(e) => setCurrentInvoice({ ...currentInvoice, amount: Number(e.target.value) })}
                            className="w-full bg-[var(--color-background)] border border-[var(--color-border)] rounded-md px-3 py-2 focus:ring-1 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                        />
                        {errors.amount && <p className="text-red-400 text-xs mt-1">{errors.amount}</p>}
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-1">وضعیت</label>
                        <select
                            value={currentInvoice?.status || 'در انتظار پرداخت'}
                            onChange={(e) => setCurrentInvoice({ ...currentInvoice, status: e.target.value as Invoice['status'] })}
                            className="w-full bg-[var(--color-background)] border border-[var(--color-border)] rounded-md px-3 py-2 focus:ring-1 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                        >
                            <option>در انتظار پرداخت</option>
                            <option>پرداخت شده</option>
                        </select>
                    </div>
                    {currentInvoice?.status === 'در انتظار پرداخت' && (
                        <div>
                            <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-1">تاریخ سررسید (اختیاری)</label>
                            <input
                                type="text"
                                placeholder="مثال: ۱۴۰۳/۰۵/۰۱"
                                value={currentInvoice?.dueDate || ''}
                                onChange={(e) => setCurrentInvoice({ ...currentInvoice, dueDate: e.target.value })}
                                className="w-full bg-[var(--color-background)] border border-[var(--color-border)] rounded-md px-3 py-2 focus:ring-1 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                            />
                        </div>
                    )}
                </div>
                <div className="mt-6 flex justify-end space-x-3 space-x-reverse">
                    <button onClick={handleCloseModal} className="px-4 py-2 rounded-md font-semibold text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-light)]/50 transition-colors">انصراف</button>
                    <button onClick={handleSaveInvoice} className="px-4 py-2 rounded-md bg-gradient-to-r from-[var(--color-accent)] to-cyan-400 text-slate-900 font-bold transition-transform hover:scale-105">ذخیره</button>
                </div>
            </Modal>
        </div>
    );
};

export default AccountingView;