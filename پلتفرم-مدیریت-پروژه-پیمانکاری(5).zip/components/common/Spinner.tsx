
import React from 'react';

interface SpinnerProps {
  large?: boolean;
}

const Spinner: React.FC<SpinnerProps> = ({ large = false }) => {
  const sizeClass = large ? 'w-8 h-8' : 'w-5 h-5';
  return (
    <div
      className={`animate-spin rounded-full ${sizeClass} border-b-2 border-t-2 border-white mr-3`}
      role="status"
    >
      <span className="sr-only">Loading...</span>
    </div>
  );
};

export default Spinner;
