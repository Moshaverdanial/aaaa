import React from 'react';
import { CloseIcon } from '../icons/Icons';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 animate-fadeIn"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div 
        className="bg-slate-900/40 backdrop-blur-xl p-6 rounded-lg shadow-xl w-full max-w-lg m-4 border border-[var(--color-border)]/50 animate-scaleIn"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h4 id="modal-title" className="text-lg font-bold text-white">{title}</h4>
          <button 
            onClick={onClose} 
            className="text-[var(--color-text-secondary)] hover:text-white"
            aria-label="بستن"
          >
            <CloseIcon />
          </button>
        </div>
        <div>
          {children}
        </div>
      </div>
    </div>
  );
};

export default Modal;