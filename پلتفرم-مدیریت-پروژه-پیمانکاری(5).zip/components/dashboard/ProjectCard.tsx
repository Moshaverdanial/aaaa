import React from 'react';
import { Project, ProjectStatus } from '../../types';
import { ArrowRightIcon } from '../icons/Icons';

interface ProjectCardProps {
  project: Project;
  onSelect: () => void;
}

const StatusBadge: React.FC<{ status: ProjectStatus }> = ({ status }) => {
    const statusStyles = {
        [ProjectStatus.InProgress]: {
            bg: 'bg-sky-500/10',
            dot: 'bg-sky-400',
            text: 'text-sky-400',
        },
        [ProjectStatus.Completed]: {
            bg: 'bg-emerald-500/10',
            dot: 'bg-emerald-400',
            text: 'text-emerald-400',
        },
        [ProjectStatus.Planning]: {
            bg: 'bg-slate-500/10',
            dot: 'bg-slate-400',
            text: 'text-slate-400',
        },
    };

    const currentStyle = statusStyles[status];

    return (
        <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${currentStyle.bg}`}>
            <span className={`w-2 h-2 mr-1.5 rounded-full ${currentStyle.dot}`}></span>
            <span className={currentStyle.text}>{status}</span>
        </div>
    );
};


const ProjectCard: React.FC<ProjectCardProps> = ({ project, onSelect }) => {
  return (
    <div 
      onClick={onSelect}
      className="bg-[var(--color-surface)] rounded-xl overflow-hidden shadow-lg hover:shadow-2xl hover:shadow-[var(--color-accent)]/20 transition-all duration-300 ease-in-out transform hover:-translate-y-1 cursor-pointer border border-[var(--color-border)] hover:border-[var(--color-accent)]/30 group animate-fadeInUp"
    >
      <div className="overflow-hidden">
        <img className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105" src={project.thumbnail} alt={project.name} />
      </div>
      <div className="p-5">
        <h3 className="font-bold text-lg text-[var(--color-text-primary)] mb-1">{project.name}</h3>
        <p className="text-sm text-[var(--color-text-secondary)] mb-4">{project.client}</p>
        <div className="flex justify-between items-center mb-4">
            <StatusBadge status={project.status} />
            <span className="text-xs text-[var(--color-text-secondary)]">{project.startDate}</span>
        </div>
        <div className="flex justify-between items-center">
            <p className="text-[var(--color-text-primary)] font-semibold">{project.budget}</p>
            <div className="opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all text-[var(--color-accent)]">
                <ArrowRightIcon />
            </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;
