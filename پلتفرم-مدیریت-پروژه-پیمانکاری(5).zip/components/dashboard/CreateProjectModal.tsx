import React, { useState, useEffect } from 'react';
import { Project, Invoice, ProjectTemplate, TemplateKey } from '../../types';
import Modal from '../common/Modal';
import { HomeModernIcon, BuildingOfficeIcon, WrenchScrewdriverIcon } from '../icons/Icons';

interface CreateProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (projectData: Omit<Project, 'id' | 'status' | 'thumbnail'>, initialInvoice?: Omit<Invoice, 'id' | 'date'>) => void;
}

const templates: ProjectTemplate[] = [
  {
    key: 'residential',
    name: 'ویلای مسکونی',
    icon: <HomeModernIcon />,
    defaultValues: {
      name: 'پروژه ویلایی جدید',
      budget: '۴ میلیارد تومان',
      initialInvoice: {
        description: 'هزینه جواز ساخت',
        amount: 8000000,
        status: 'در انتظار پرداخت',
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toLocaleDateString('fa-IR-u-nu-latn').replace(/\//g, '/'),
      }
    }
  },
  {
    key: 'office',
    name: 'فضای اداری',
    icon: <BuildingOfficeIcon />,
    defaultValues: {
      name: 'پروژه اداری جدید',
      budget: '۱۰ میلیارد تومان',
    }
  },
  {
    key: 'renovation',
    name: 'بازسازی',
    icon: <WrenchScrewdriverIcon />,
    defaultValues: {
      name: 'پروژه بازسازی جدید',
      budget: '۱.۵ میلیارد تومان',
    }
  }
];

const CreateProjectModal: React.FC<CreateProjectModalProps> = ({ isOpen, onClose, onCreate }) => {
  const [selectedTemplate, setSelectedTemplate] = useState<TemplateKey>('residential');
  const [projectName, setProjectName] = useState('');
  const [client, setClient] = useState('');
  const [budget, setBudget] = useState('');
  const [startDate, setStartDate] = useState(new Date().toLocaleDateString('fa-IR-u-nu-latn').replace(/\//g, '/'));
  const [errors, setErrors] = useState<{ name?: string, client?: string }>({});

  useEffect(() => {
    const template = templates.find(t => t.key === selectedTemplate);
    if (template) {
      setProjectName(template.defaultValues.name);
      setBudget(template.defaultValues.budget);
    }
  }, [selectedTemplate]);
  
  const validate = () => {
    const newErrors: { name?: string, client?: string } = {};
    if (!projectName.trim()) newErrors.name = "نام پروژه الزامی است.";
    if (!client.trim()) newErrors.client = "نام کارفرما الزامی است.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    
    const template = templates.find(t => t.key === selectedTemplate);

    onCreate({
        name: projectName,
        client,
        budget,
        startDate
    }, template?.defaultValues.initialInvoice);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="ایجاد پروژه جدید">
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">۱. یک الگو انتخاب کنید</label>
          <div className="grid grid-cols-3 gap-3">
            {templates.map(template => (
              <button
                key={template.key}
                onClick={() => setSelectedTemplate(template.key)}
                className={`flex flex-col items-center justify-center p-4 rounded-lg border-2 transition-all duration-200 ${
                  selectedTemplate === template.key
                    ? 'border-[var(--color-accent)] bg-[var(--color-accent)]/10 shadow-lg'
                    : 'border-[var(--color-border)] bg-[var(--color-surface)] hover:border-[var(--color-accent)]/50'
                }`}
              >
                <div className={selectedTemplate === template.key ? 'text-[var(--color-accent)]' : 'text-[var(--color-text-secondary)]'}>
                    {template.icon}
                </div>
                <span className={`mt-2 text-sm font-semibold ${selectedTemplate === template.key ? 'text-white' : 'text-[var(--color-text-secondary)]'}`}>{template.name}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">۲. جزئیات پروژه را وارد کنید</label>
          <div className="space-y-4">
             <div>
                <label className="block text-xs font-medium text-[var(--color-text-secondary)] mb-1">نام پروژه</label>
                <input type="text" value={projectName} onChange={e => setProjectName(e.target.value)} className="form-input" />
                {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
            </div>
             <div>
                <label className="block text-xs font-medium text-[var(--color-text-secondary)] mb-1">نام کارفرما</label>
                <input type="text" placeholder="نام کارفرما را وارد کنید" value={client} onChange={e => setClient(e.target.value)} className="form-input" />
                {errors.client && <p className="text-red-400 text-xs mt-1">{errors.client}</p>}
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-xs font-medium text-[var(--color-text-secondary)] mb-1">بودجه</label>
                    <input type="text" value={budget} onChange={e => setBudget(e.target.value)} className="form-input" />
                </div>
                <div>
                    <label className="block text-xs font-medium text-[var(--color-text-secondary)] mb-1">تاریخ شروع</label>
                    <input type="text" value={startDate} onChange={e => setStartDate(e.target.value)} className="form-input" />
                </div>
             </div>
          </div>
        </div>
      </div>
      <div className="mt-8 flex justify-end space-x-3 space-x-reverse">
        <button onClick={onClose} className="px-4 py-2 rounded-md font-semibold text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-light)]/50 transition-colors">انصراف</button>
        <button onClick={handleSubmit} className="px-6 py-2 rounded-md bg-gradient-to-r from-[var(--color-accent)] to-cyan-400 text-slate-900 font-bold transition-transform hover:scale-105">ایجاد پروژه</button>
      </div>
      <style jsx>{`
        .form-input {
          width: 100%;
          background-color: var(--color-background);
          border: 1px solid var(--color-border);
          border-radius: 0.375rem;
          padding: 0.5rem 0.75rem;
          color: var(--color-text-primary);
          transition: border-color 0.2s, box-shadow 0.2s;
        }
        .form-input:focus {
          outline: none;
          border-color: var(--color-accent);
          box-shadow: 0 0 0 1px var(--color-accent);
        }
      `}</style>
    </Modal>
  );
};

export default CreateProjectModal;
