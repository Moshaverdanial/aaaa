import React, { useState } from 'react';
import { Project, ProjectStatus, Invoice } from '../../types';
import ProjectCard from './ProjectCard';
import CreateProjectModal from './CreateProjectModal';
import { PlusIcon } from '../icons/Icons';

const mockProjects: Project[] = [
  { id: 1, name: 'پروژه ویلایی مدرن', client: 'جناب آقای رضایی', status: ProjectStatus.InProgress, thumbnail: 'https://picsum.photos/seed/project1/600/400', startDate: '۱۴۰۳/۰۲/۱۵', budget: '۵ میلیارد تومان' },
  { id: 2, name: 'ساختمان اداری هوشمند', client: 'شرکت فناوری نوین', status: ProjectStatus.Completed, thumbnail: 'https://picsum.photos/seed/project2/600/400', startDate: '۱۴۰۲/۰۷/۲۰', budget: '۱۲ میلیارد تومان' },
  { id: 3, name: 'مجتمع مسکونی نیلوفر', client: 'تعاونی مسکن بهاران', status: ProjectStatus.Planning, thumbnail: 'https://picsum.photos/seed/project3/600/400', startDate: '۱۴۰۳/۰۹/۰۱', budget: '۲۵ میلیارد تومان' },
  { id: 4, name: 'بازسازی پنت‌هاوس', client: 'خانم اکبری', status: ProjectStatus.InProgress, thumbnail: 'https://picsum.photos/seed/project4/600/400', startDate: '۱۴۰۳/۰۵/۱۰', budget: '۲.۵ میلیارد تومان' },
];

const Dashboard: React.FC<{ onSelectProject: (project: Project) => void; }> = ({ onSelectProject }) => {
  const [projects, setProjects] = useState<Project[]>(mockProjects);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const handleCreateProject = (
    projectData: Omit<Project, 'id' | 'status' | 'thumbnail'>, 
    initialInvoice?: Omit<Invoice, 'id' | 'date'>
  ) => {
      const newProject: Project = {
        ...projectData,
        id: Date.now(),
        status: ProjectStatus.Planning,
        thumbnail: `https://picsum.photos/seed/project${Date.now()}/600/400`,
      };
      setProjects(prevProjects => [newProject, ...prevProjects]);

      if (initialInvoice) {
        const invoiceKey = `project-invoices-${newProject.id}`;
        const newInvoiceEntry: Invoice = {
          ...initialInvoice,
          id: `INV-${Date.now()}`,
          date: new Date().toLocaleDateString('fa-IR-u-nu-latn').replace(/\//g, '/'),
        };
        // Set the initial invoice in localStorage for the new project
        localStorage.setItem(invoiceKey, JSON.stringify([newInvoiceEntry]));
      }
      
      setIsModalOpen(false);
  };


  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        {/* The title is in the Header component, so we don't need another one here */}
        <div></div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center bg-gradient-to-r from-[var(--color-accent)] to-cyan-400 text-slate-900 font-bold py-2.5 px-5 rounded-lg transition-all duration-300 ease-in-out transform hover:scale-105 hover:shadow-[0_0_20px_var(--color-accent)]"
        >
          <PlusIcon />
          <span className="mr-2">پروژه جدید</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {projects.map((project, index) => (
          <div key={project.id} className={index === 0 ? 'animate-popIn' : ''} style={{ animationDelay: `${index * 75}ms` }}>
            <ProjectCard project={project} onSelect={() => onSelectProject(project)} />
          </div>
        ))}
      </div>

      <CreateProjectModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onCreate={handleCreateProject}
      />
    </div>
  );
};

export default Dashboard;