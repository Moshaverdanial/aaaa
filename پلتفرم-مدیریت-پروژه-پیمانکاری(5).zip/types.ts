import React from 'react';

export const UserType = {
  Client: 'کارفرما',
  Colleague: 'همکار',
} as const;
export type UserType = typeof UserType[keyof typeof UserType];

export const ProjectStatus = {
  InProgress: 'در حال انجام',
  Completed: 'تکمیل شده',
  Planning: 'در حال برنامه ریزی',
} as const;
export type ProjectStatus = typeof ProjectStatus[keyof typeof ProjectStatus];

export interface Project {
  id: number;
  name: string;
  client: string;
  status: ProjectStatus;
  thumbnail: string;
  startDate: string;
  budget: string;
}

export interface Invoice {
  id: string;
  description: string;
  date: string;
  dueDate?: string;
  amount: number;
  status: 'پرداخت شده' | 'در انتظار پرداخت';
  isDeleting?: boolean;
}

export interface Plot {
  id: string;
  plotNumber: string;
  x: number; // percentage
  y: number; // percentage
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: string;
}

export type TemplateKey = 'residential' | 'office' | 'renovation';

export interface ProjectTemplate {
  key: TemplateKey;
  name: string;
  icon: React.ReactNode;
  defaultValues: {
    name: string;
    budget: string;
    initialInvoice?: Omit<Invoice, 'id' | 'date'>;
  };
}
