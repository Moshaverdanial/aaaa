import { GoogleGenAI, Modality, Content } from "@google/genai";
import type { Project, UserType, ChatMessage } from '../types';

// Per coding guidelines, initialize with apiKey from process.env.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Helper to convert file to base64 for multimodal prompts
const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: {
      data: await base64EncodedDataPromise,
      mimeType: file.type,
    },
  };
};

/**
 * Generates a 3D view from a 2D plan image file.
 * @param file The 2D plan image file.
 * @returns A promise that resolves to a base64 data URL of the generated image.
 */
export async function generate3dView(file: File): Promise<string> {
  const imagePart = await fileToGenerativePart(file);
  const textPart = {
    text: 'این نقشه دو بعدی معماری را به یک رندر سه بعدی فوتورئالیستی از نمای بیرونی ساختمان تبدیل کن.'
  };

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image-preview',
    contents: {
      parts: [imagePart, textPart],
    },
    config: {
        responseModalities: [Modality.IMAGE, Modality.TEXT],
    },
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      const base64ImageBytes: string = part.inlineData.data;
      return `data:${part.inlineData.mimeType};base64,${base64ImageBytes}`;
    }
  }

  const fallbackText = response.text;
  if (fallbackText) {
      throw new Error(`هوش مصنوعی نتوانست تصویری ایجاد کند: ${fallbackText}`);
  }
  
  throw new Error('هیچ تصویری توسط هوش مصنوعی ایجاد نشد.');
}

/**
 * Generates a project summary tailored to the user type.
 * @param project The project data.
 * @param userType The type of user requesting the summary.
 * @returns A promise that resolves to the generated summary string.
 */
export async function generateProjectSummary(project: Project, userType: UserType): Promise<string> {
    const projectDetails = `
      نام پروژه: ${project.name}
      کارفرما: ${project.client}
      وضعیت: ${project.status}
      تاریخ شروع: ${project.startDate}
      بودجه: ${project.budget}
    `;

    const systemInstruction = userType === 'کارفرما'
        ? 'شما یک مدیر پروژه هستید که خلاصه‌ای واضح و حرفه‌ای از وضعیت پروژه برای کارفرما می‌نویسید. لحن شما باید رسمی، محترمانه و اطمینان‌بخش باشد.'
        : 'شما یک مدیر پروژه هستید که خلاصه‌ای مختصر و مفید از وضعیت پروژه برای همکاران تیم می‌نویسید. لحن شما باید دوستانه، فنی و انگیزه‌بخش باشد.';
    
    const userPrompt = `بر اساس اطلاعات زیر، یک خلاصه کوتاه (حدود ۲-۳ جمله) از پروژه برای اشتراک‌گذاری آماده کن:\n\n${projectDetails}`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: userPrompt,
        config: {
            systemInstruction: systemInstruction,
        }
    });

    return response.text;
}

/**
 * Generates a chat response from the AI assistant.
 * @param project The current project context.
 * @param userType The type of user chatting.
 * @param chatHistory The history of the conversation.
 * @param currentMessage The latest message from the user.
 * @returns A promise that resolves to the AI's response string.
 */
export async function generateChatResponse(project: Project, userType: UserType, chatHistory: ChatMessage[], currentMessage: string): Promise<string> {
    const projectContext = `
      اطلاعات پروژه فعلی:
      - نام پروژه: ${project.name}
      - کارفرما: ${project.client}
      - وضعیت: ${project.status}
      - تاریخ شروع: ${project.startDate}
      - بودجه: ${project.budget}
    `;

    const systemInstruction = `شما یک دستیار هوشمند در زمینه مدیریت پروژه ساختمانی هستید. شما به سوالات مربوط به پروژه "${project.name}" پاسخ می‌دهید. مخاطب شما یک "${userType}" است. پاسخ‌های شما باید کوتاه، دقیق و مرتبط با اطلاعات پروژه باشد. اطلاعات پروژه به شرح زیر است:\n${projectContext}`;
    
    // The chatHistory from ChatView already contains the latest user message.
    // The history for the chat API should be all messages *before* the current one.
    const historyMessages = chatHistory.slice(0, -1);

    const history: Content[] = historyMessages.map(message => ({
        role: message.sender === 'ai' ? 'model' : 'user',
        parts: [{ text: message.text }],
    }));

    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: systemInstruction,
      },
      history: history,
    });
    
    const response = await chat.sendMessage({ message: currentMessage });

    return response.text;
}
