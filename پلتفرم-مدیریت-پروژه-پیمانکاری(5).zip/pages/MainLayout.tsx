import React, { useState } from 'react';
import Sidebar from '../components/layout/Sidebar';
import Header from '../components/layout/Header';
import Dashboard from '../components/dashboard/Dashboard';
import ProjectView from '../components/project/ProjectView';
import { Project, UserType } from '../types';

interface MainLayoutProps {
  userType: UserType;
  onLogout: () => void;
}

const MainLayout: React.FC<MainLayoutProps> = ({ userType, onLogout }) => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const handleSelectProject = (project: Project) => {
    setSelectedProject(project);
  };

  const handleBackToDashboard = () => {
    setSelectedProject(null);
  };

  return (
    <div className="flex h-screen bg-[var(--color-background)] text-[var(--color-text-primary)]">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header userType={userType} onLogout={onLogout} onBack={selectedProject ? handleBackToDashboard : undefined} />
        <main 
          key={selectedProject ? selectedProject.id : 'dashboard'} 
          className="flex-1 overflow-x-hidden overflow-y-auto bg-[var(--color-background)] p-4 sm:p-6 md:p-8 animate-fadeIn"
        >
          {selectedProject ? (
            <ProjectView project={selectedProject} userType={userType} />
          ) : (
            <Dashboard onSelectProject={handleSelectProject} />
          )}
        </main>
      </div>
    </div>
  );
};

export default MainLayout;