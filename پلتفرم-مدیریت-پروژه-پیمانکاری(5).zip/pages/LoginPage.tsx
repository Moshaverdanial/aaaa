import React from 'react';
import { UserType } from '../types';

interface LoginPageProps {
  onLogin: (userType: UserType) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  return (
    <div
      className="flex items-center justify-center min-h-screen bg-cover bg-center"
      style={{ backgroundImage: "url('https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=2670&auto=format&fit=crop')" }}
    >
      <div className="absolute inset-0 bg-black/50"></div>
      <div className="relative p-8 bg-slate-900/40 backdrop-blur-xl border border-[var(--color-border)]/50 rounded-xl shadow-2xl text-center max-w-sm w-full m-4 animate-fadeInDown">
        <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">Gemini App</h1>
        <p className="text-[var(--color-text-secondary)] mb-8">پلتفرم مدیریت پروژه پیمانکاری</p>
        <div className="space-y-4">
          <button
            onClick={() => onLogin(UserType.Client)}
            className="w-full bg-gradient-to-r from-[var(--color-accent)] to-cyan-400 text-slate-900 font-bold py-3 px-4 rounded-lg transition-all duration-300 ease-in-out transform hover:scale-105 hover:shadow-[0_0_20px_var(--color-accent)]"
          >
            {UserType.Client}
          </button>
          <button
            onClick={() => onLogin(UserType.Colleague)}
            className="w-full bg-gradient-to-r from-[var(--color-accent)] to-cyan-400 text-slate-900 font-bold py-3 px-4 rounded-lg transition-all duration-300 ease-in-out transform hover:scale-105 hover:shadow-[0_0_20px_var(--color-accent)]"
          >
            {UserType.Colleague}
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;