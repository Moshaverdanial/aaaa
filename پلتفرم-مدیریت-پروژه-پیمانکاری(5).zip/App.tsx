import React, { useState } from 'react';
import LoginPage from './pages/LoginPage';
import MainLayout from './pages/MainLayout';
import { UserType } from './types';

function App() {
  const [user, setUser] = useState<{ type: UserType } | null>(null);

  const handleLogin = (userType: UserType) => {
    setUser({ type: userType });
  };

  const handleLogout = () => {
    setUser(null);
  };

  return (
    <div className="bg-[var(--color-background)] text-[var(--color-text-primary)] min-h-screen">
      {user ? (
        <MainLayout userType={user.type} onLogout={handleLogout} />
      ) : (
        <LoginPage onLogin={handleLogin} />
      )}
    </div>
  );
}

export default App;
